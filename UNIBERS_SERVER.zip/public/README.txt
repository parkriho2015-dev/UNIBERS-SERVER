여기에 기존 유니버즈 리그 index.html을 넣으면 됩니다.
사이트에서 /api/login, /api/results를 호출해 서버와 연결하세요.
